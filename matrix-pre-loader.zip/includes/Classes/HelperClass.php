<?php
/**
 * @package matrixPreLoader
 */
namespace matrixloader\Classes;
defined('ABSPATH') or die('!');


class HelperClass {
	

}
