import Dashboard from './Components/Dashboard';

export const routes = [
    {
        path: '/',
        name: 'dashboard',
        component: Dashboard
    }
  
];
