<?php

# Silence of gold.