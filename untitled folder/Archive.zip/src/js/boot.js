import matrixloader from './plugin_main_js_file';

window.matrixloader = new matrixloader();
